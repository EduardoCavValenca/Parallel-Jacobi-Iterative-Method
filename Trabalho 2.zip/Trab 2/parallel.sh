#!/bin/bash

read -e -r -p "Entre o tamanho da matriz, 3 quantidades de processos e 3 quantidades de threads a serem executadas: " TAMANHO PROC1 PROC2 PROC3 THREADS1 THREADS2 THREADS3

PROC=( $PROC1 $PROC2 $PROC3 )
THREADS=( $THREADS1 $THREADS2 $THREADS3 )

mkdir paralelo_segundo

# Clears the csv and saves the matrix size, number of processors and number of threads
> paralelo/jacobipar.csv
printf "Tamanho, Processos, Threads, Tempos\n" >> paralelo/jacobipar.csv

# runs only parallel jacobi
for i in $(seq 1 30); do
    printf "Iteração $i:\n\tExecutando Jacobiseq\n"
    for P in ${PROC[@]}; do
        for T in ${THREADS[@]}; do
            printf "\tExecutando jacobipar com $P processadores e $T threads em cada\n"
            printf "$TAMANHO, $P, $T, " >> paralelo/jacobipar.csv
            mpirun -np ${P} --hostfile halley.txt jacobipar ${TAMANHO} ${T} | grep -Eo "[0-9]+\.[0-9]+" >> paralelo/jacobipar.csv
        done
    done
done

printf "Terminou\n"